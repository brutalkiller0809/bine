import React from 'react';
import { X } from 'lucide-react';
import { ContractData } from '../../types/contract';
import { ContractResults } from './ContractResults';
import { ContractForm } from './ContractForm';

interface ContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (address: string) => Promise<void>;
  data: ContractData | null;
  isLoading: boolean;
  error: string | null;
}

export function ContractModal({
  isOpen,
  onClose,
  onSubmit,
  data,
  isLoading,
  error
}: ContractModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl mx-4 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
          aria-label="Close modal"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-6">
          <h2 className="text-2xl font-bold mb-6">Contract Investigation</h2>
          
          <ContractForm onSubmit={onSubmit} isLoading={isLoading} />
          
          {error && (
            <div className="text-red-500 text-sm mt-2">{error}</div>
          )}

          {data && <ContractResults data={data} />}
        </div>
      </div>
    </div>
  );
}