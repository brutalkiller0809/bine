import React, { useState, useEffect } from 'react';
import { ArrowRight, TrendingUp } from 'lucide-react';
import Button from './ui/Button';
import InvestigationModal from './InvestigationModal';

export default function Hero() {
  const [text, setText] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const fullText = 'Investigate Before You Invest!';
  
  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex <= fullText.length) {
        setText(fullText.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <div className="min-h-screen pt-20 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1 className="text-4xl md:text-6xl font-bold">
                {text}
                <span className="animate-blink">|</span>
              </h1>
              
              <p className="text-xl text-gray-600">
                The first cryptocurrency with built-in rugcheck integration.
                Protect your investments with Inspector Gadget's smart contract analysis.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => setIsModalOpen(true)}
                  className="flex items-center justify-center space-x-2"
                >
                  <span>Start Investigating</span>
                  <ArrowRight size={20} />
                </Button>

                <Button
                  variant="secondary"
                  className="flex items-center justify-center space-x-2"
                >
                  <span>Buy $GADGET</span>
                </Button>
              </div>

              <div className="flex items-center space-x-4 bg-white p-4 rounded-lg shadow-lg w-fit">
                <TrendingUp className="text-green-500" />
                <div>
                  <p className="text-sm text-gray-600">Current Price</p>
                  <p className="text-xl font-bold">$0.000123</p>
                </div>
                <span className="text-green-500">+15.4%</span>
              </div>
            </div>

            <div className="relative flex justify-center items-center">
              <div className="w-[80%]">
                <img
                  src="/src/gadget.jpg"
                  alt="Inspector Gadget"
                  className="rounded-lg shadow-xl w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <InvestigationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
}