import React from 'react';

interface TrustIndicatorProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function TrustIndicator({ icon, title, description }: TrustIndicatorProps) {
  return (
    <div className="flex items-start space-x-4">
      <div className="p-2 bg-blue-50 rounded-lg">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-lg">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}