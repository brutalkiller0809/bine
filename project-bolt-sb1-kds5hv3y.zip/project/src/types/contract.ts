export interface ContractIssue {
  severity: 'info' | 'warning' | 'critical';
  message: string;
}

export interface ContractData {
  riskLevel: 'low' | 'medium' | 'high';
  score: number;
  issues: ContractIssue[];
  contractAddress: string;
}