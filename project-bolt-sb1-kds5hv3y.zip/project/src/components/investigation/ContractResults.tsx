import React from 'react';
import { Shield, AlertTriangle, Info } from 'lucide-react';
import { ContractData } from '../../types/contract';

interface ContractResultsProps {
  data: ContractData;
}

export function ContractResults({ data }: ContractResultsProps) {
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="text-red-500" />;
      case 'warning':
        return <AlertTriangle className="text-yellow-500" />;
      default:
        return <Info className="text-blue-500" />;
    }
  };

  return (
    <div className="mt-6 space-y-4">
      <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
        <div>
          <h3 className="font-semibold">Security Score</h3>
          <p className="text-2xl font-bold text-blue-600">{data.score}/100</p>
        </div>
        <div className="flex items-center space-x-2">
          <Shield className={`w-6 h-6 ${
            data.riskLevel === 'low' ? 'text-green-500' :
            data.riskLevel === 'medium' ? 'text-yellow-500' :
            'text-red-500'
          }`} />
          <span className="font-semibold">
            {data.riskLevel.toUpperCase()} RISK
          </span>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-semibold">Findings</h3>
        {data.issues.map((issue, index) => (
          <div
            key={index}
            className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg"
          >
            {getSeverityIcon(issue.severity)}
            <div>
              <p className="text-sm">{issue.message}</p>
              <span className={`text-xs font-medium ${
                issue.severity === 'critical' ? 'text-red-500' :
                issue.severity === 'warning' ? 'text-yellow-500' :
                'text-blue-500'
              }`}>
                {issue.severity.toUpperCase()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}