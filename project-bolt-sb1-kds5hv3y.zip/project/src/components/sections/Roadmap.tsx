import React from 'react';

export default function Roadmap() {
  return (
    <section id="roadmap" className="py-20 bg-gray-50">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Roadmap - Paving the Path to Safety
        </h2>

        <div className="max-w-4xl mx-auto">
          <Timeline />
        </div>
      </div>
    </section>
  );
}

function Timeline() {
  const milestones = [
    {
      quarter: 'Q1 2024',
      items: [
        'Launch Inspector Gadget Coin on Radium.io and DexScreener',
        'Integrate with rugcheck for real-time coin analysis',
        'Launch website and beta testing for analysis tools'
      ]
    },
    {
      quarter: 'Q2 2025',
      items: [
        'Develop a mobile-friendly interface for coin safety checks',
        'Host community-driven events and AMAs'
      ]
    },
    {
      quarter: 'Q3 2025',
      items: [
        'Add advanced analytics (liquidity trends, holder analysis)',
        'Partner with influencers to promote safe investing'
      ]
    },
    {
      quarter: 'Q4 2025',
      items: [
        'Expand to multi-chain analysis',
        'Introduce staking mechanisms for holders'
      ]
    }
  ];

  return (
    <div className="space-y-12">
      {milestones.map((milestone, index) => (
        <div key={index} className="relative pl-8 border-l-2 border-blue-200">
          <div className="absolute -left-2 top-0 w-4 h-4 rounded-full bg-blue-500" />
          <div className="mb-4">
            <h3 className="text-xl font-bold text-blue-600">{milestone.quarter}</h3>
            <ul className="mt-2 space-y-2">
              {milestone.items.map((item, itemIndex) => (
                <li key={itemIndex} className="text-gray-600">{item}</li>
              ))}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
}