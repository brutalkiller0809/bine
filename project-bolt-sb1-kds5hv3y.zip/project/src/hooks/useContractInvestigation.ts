import { useState } from 'react';
import { ContractData } from '../types/contract';
import { investigateCoin } from '../services/investigationService';

export function useContractInvestigation() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<ContractData | null>(null);

  const investigate = async (address: string) => {
    try {
      setIsLoading(true);
      setError(null);
      const result = await investigateCoin(address);
      setData(result);
    } catch (err) {
      setError('Failed to investigate contract. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isModalOpen,
    setIsModalOpen,
    isLoading,
    error,
    data,
    investigate
  };
}