import React from 'react';
import { Shield, CheckCircle, Award } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="w-64 h-64 md:w-80 md:h-80 mx-auto">
              <div className="absolute inset-0 bg-[#2B4BF2]/10 rounded-full animate-pulse"></div>
              <img
                src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80"
                alt="Inspector Gadget Badge"
                className="rounded-full shadow-xl"
              />
            </div>
          </div>

          <div className="space-y-8">
            <h2 className="text-3xl md:text-4xl font-bold">Securing the Future of DeFi</h2>
            <p className="text-lg text-gray-600">
              Inspector Gadget Coin revolutionizes cryptocurrency security through our
              exclusive partnership with rugcheck.xyz. We're not just another meme coin -
              we're building the future of safe DeFi investing.
            </p>

            <div className="space-y-4">
              <TrustIndicator
                icon={<Shield className="text-[#2B4BF2]" />}
                title="Rugcheck.xyz Integration"
                description="Real-time smart contract analysis and security monitoring"
              />
              <TrustIndicator
                icon={<CheckCircle className="text-[#2B4BF2]" />}
                title="Audited & Secure"
                description="Multiple independent security audits completed"
              />
              <TrustIndicator
                icon={<Award className="text-[#2B4BF2]" />}
                title="Community Driven"
                description="Fully decentralized governance and development"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustIndicator({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start space-x-4">
      <div className="p-2 bg-blue-50 rounded-lg">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-lg">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}