import React from 'react';
import { Search } from 'lucide-react';

export default function Logo() {
  return (
    <div className="flex items-center space-x-2">
      <Search size={32} className="text-[#2B4BF2]" />
      <span className="text-xl font-bold">$GADGET</span>
    </div>
  );
}