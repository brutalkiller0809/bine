import React from 'react';

interface AnimatedImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function AnimatedImage({ src, alt, className = '' }: AnimatedImageProps) {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div className="absolute inset-0 bg-[#2B4BF2]/10 rounded-full animate-pulse"></div>
      <img
        src={src}
        alt={alt}
        className="relative z-10 rounded-full shadow-xl w-full h-full object-cover"
      />
    </div>
  );
}