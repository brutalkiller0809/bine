import React, { useEffect, useRef } from 'react';

interface Point {
  x: number;
  y: number;
  originX: number;
  originY: number;
  distanceFromCenter: number;
  angle: number;
}

interface SplineEffectProps {
  imagePath: string;
  width?: number;
  height?: number;
}

export default function SplineEffect({ imagePath, width = 500, height = 500 }: SplineEffectProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const points = useRef<Point[]>([]);
  const image = useRef<HTMLImageElement>(new Image());
  const animationFrameId = useRef<number>();
  const mousePosition = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = width;
    canvas.height = height;

    // Load image
    image.current.src = imagePath;
    image.current.onload = initializePoints;

    // Initialize points
    function initializePoints() {
      const density = 30;
      const numPoints = (width * height) / (density * density);
      
      for (let i = 0; i < numPoints; i++) {
        const x = Math.random() * width;
        const y = Math.random() * height;
        points.current.push({
          x,
          y,
          originX: x,
          originY: y,
          distanceFromCenter: 0,
          angle: 0
        });
      }

      animate();
    }

    // Animation loop
    function animate() {
      ctx.clearRect(0, 0, width, height);
      
      // Draw image
      ctx.globalAlpha = 0.9;
      ctx.drawImage(image.current, 0, 0, width, height);
      
      // Update and draw points
      for (let i = 0; i < points.current.length; i++) {
        const point = points.current[i];
        
        // Calculate distance from mouse
        const dx = mousePosition.current.x - point.x;
        const dy = mousePosition.current.y - point.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // Apply force field effect
        const force = Math.max(100 - distance, 0);
        const angle = Math.atan2(dy, dx);
        
        point.x += Math.cos(angle) * force * 0.01;
        point.y += Math.sin(angle) * force * 0.01;
        
        // Spring back to original position
        point.x += (point.originX - point.x) * 0.05;
        point.y += (point.originY - point.y) * 0.05;
        
        // Draw point
        ctx.beginPath();
        ctx.arc(point.x, point.y, 1, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(43, 75, 242, 0.5)';
        ctx.fill();
      }
      
      animationFrameId.current = requestAnimationFrame(animate);
    }

    // Mouse move handler
    function handleMouseMove(e: MouseEvent) {
      const rect = canvas.getBoundingClientRect();
      mousePosition.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    }

    // Touch move handler
    function handleTouchMove(e: TouchEvent) {
      if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        mousePosition.current = {
          x: e.touches[0].clientX - rect.left,
          y: e.touches[0].clientY - rect.top
        };
      }
    }

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('touchmove', handleTouchMove);

    return () => {
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('touchmove', handleTouchMove);
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [width, height]);

  return (
    <canvas
      ref={canvasRef}
      className="rounded-lg shadow-xl"
      style={{ maxWidth: '100%', height: 'auto' }}
    />
  );
}