document.getElementById("investigate-btn").addEventListener("click", fetchContractData);
document.getElementById("close-btn").addEventListener("click", closeModal);

function fetchContractData() {
  const contractModal = document.getElementById("contract-modal");
  const contractDataDiv = document.getElementById("contract-data");

  // Open the modal
  contractModal.style.display = "block";
  contractDataDiv.innerHTML = "<p>Fetching contract data...</p>";

  // Example API call (replace with a real provider)
  const contractAddress = "YOUR_CONTRACT_ADDRESS"; // Example address
  const apiUrl = `https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=${contractAddress}&apikey=YOUR_API_KEY`;

  fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      if (data.status === "1") {
        contractDataDiv.innerHTML = `
          <p><strong>Contract Address:</strong> ${contractAddress}</p>
          <p><strong>Balance:</strong> ${data.result} tokens</p>
          <p><strong>Status:</strong> Verified ✅</p>
        `;
      } else {
        contractDataDiv.innerHTML = `<p>Error: Unable to fetch data.</p>`;
      }
    })
    .catch(error => {
      contractDataDiv.innerHTML = `<p>Error fetching data: ${error.message}</p>`;
    });
}

function closeModal() {
  document.getElementById("contract-modal").style.display = "none";
}
