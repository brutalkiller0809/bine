import React from 'react';
import { Search } from 'lucide-react';
import Button from '../ui/Button';

interface InvestigateButtonProps {
  onClick: () => void;
  isLoading?: boolean;
}

export function InvestigateButton({ onClick, isLoading = false }: InvestigateButtonProps) {
  return (
    <Button
      onClick={onClick}
      isLoading={isLoading}
      className="flex items-center justify-center space-x-2"
    >
      <Search className="w-5 h-5" />
      <span>Start Investigating</span>
    </Button>
  );
}