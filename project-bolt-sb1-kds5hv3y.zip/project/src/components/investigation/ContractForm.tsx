import React, { useState } from 'react';
import Button from '../ui/Button';

interface ContractFormProps {
  onSubmit: (address: string) => Promise<void>;
  isLoading: boolean;
}

export function ContractForm({ onSubmit, isLoading }: ContractFormProps) {
  const [address, setAddress] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (address.trim()) {
      onSubmit(address.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="contract-address" className="block text-sm font-medium text-gray-700 mb-1">
          Contract Address
        </label>
        <input
          type="text"
          id="contract-address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="0x..."
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          disabled={isLoading}
        />
      </div>

      <Button
        type="submit"
        isLoading={isLoading}
        disabled={isLoading || !address.trim()}
        className="w-full"
      >
        Investigate Contract
      </Button>
    </form>
  );
}