import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/sections/About';
import Utility from './components/sections/Utility';
import Tokenomics from './components/sections/Tokenomics';
import Roadmap from './components/sections/Roadmap';
import Community from './components/sections/Community';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <About />
      <Utility />
      <Tokenomics />
      <Roadmap />
      <Community />
    </div>
  );
}

export default App;