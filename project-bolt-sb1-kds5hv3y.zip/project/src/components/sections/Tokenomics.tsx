import React from 'react';
import { PieChart, Wallet, Code, Users } from 'lucide-react';

export default function Tokenomics() {
  return (
    <section id="tokenomics" className="py-20 bg-white">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Tokenomics - Transparency at Its Core
          </h2>
          <p className="text-lg text-gray-600">
            Our token distribution is designed to ensure long-term sustainability and growth
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <TokenomicsCard
            icon={<PieChart />}
            title="80% Liquidity Pool"
            description="Ensures price stability and trading liquidity"
          />
          <TokenomicsCard
            icon={<Code />}
            title="10% Project Development"
            description="Funds website, integrations, and tools"
          />
          <TokenomicsCard
            icon={<Users />}
            title="10% Actioneers"
            description="Reserved for contributors and early supporters"
          />
        </div>

        <div className="mt-12 bg-blue-50 rounded-lg p-8">
          <h3 className="text-xl font-bold mb-4">Transaction Fee Structure</h3>
          <p className="text-gray-600">
            0.25% Buy/Sell Fee automatically added to the liquidity pool to ensure long-term growth
          </p>
        </div>
      </div>
    </section>
  );
}

function TokenomicsCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-gray-50 rounded-lg p-6 text-center">
      <div className="inline-block p-3 bg-blue-100 rounded-full mb-4">
        {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6 text-blue-600' })}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}