import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle, Info, Loader2 } from 'lucide-react';
import Button from './ui/Button';
import { investigateCoin, InvestigationResult } from '../services/investigationService';

interface InvestigationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function InvestigationModal({ isOpen, onClose }: InvestigationModalProps) {
  const [address, setAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<InvestigationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleInvestigate = async () => {
    if (!address) {
      setError('Please enter a contract address');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      const result = await investigateCoin(address);
      setResult(result);
    } catch (err) {
      setError('Failed to investigate contract. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="text-red-500" />;
      case 'warning':
        return <AlertTriangle className="text-yellow-500" />;
      default:
        return <Info className="text-blue-500" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl mx-4 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
        >
          <X size={24} />
        </button>

        <div className="p-6">
          <h2 className="text-2xl font-bold mb-4">Investigate Contract</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                Contract Address
              </label>
              <input
                type="text"
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="0x..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {error && (
              <div className="text-red-500 text-sm">{error}</div>
            )}

            <Button
              onClick={handleInvestigate}
              isLoading={isLoading}
              disabled={isLoading}
              className="w-full"
            >
              Investigate Contract
            </Button>

            {result && (
              <div className="mt-6 space-y-4">
                <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
                  <div>
                    <h3 className="font-semibold">Security Score</h3>
                    <p className="text-2xl font-bold text-blue-600">{result.score}/100</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm ${
                      result.riskLevel === 'low' ? 'text-green-500' :
                      result.riskLevel === 'medium' ? 'text-yellow-500' :
                      'text-red-500'
                    }`}>
                      {result.riskLevel.toUpperCase()} RISK
                    </span>
                    {result.riskLevel === 'low' && <CheckCircle className="text-green-500" />}
                    {result.riskLevel === 'medium' && <AlertTriangle className="text-yellow-500" />}
                    {result.riskLevel === 'high' && <AlertTriangle className="text-red-500" />}
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Findings</h3>
                  {result.issues.map((issue, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg"
                    >
                      {getSeverityIcon(issue.severity)}
                      <div>
                        <p className="text-sm">{issue.message}</p>
                        <span className={`text-xs ${
                          issue.severity === 'critical' ? 'text-red-500' :
                          issue.severity === 'warning' ? 'text-yellow-500' :
                          'text-blue-500'
                        }`}>
                          {issue.severity.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}