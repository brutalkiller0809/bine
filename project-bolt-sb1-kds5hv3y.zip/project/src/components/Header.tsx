import React, { useState } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import Logo from './Logo';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-200">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Logo />
          
          <div className="hidden md:flex items-center space-x-8">
            <NavLinks />
            <LanguageSelector />
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-6">
            <NavLinks mobile />
            <div className="mt-4">
              <LanguageSelector />
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}

function NavLinks({ mobile }: { mobile?: boolean }) {
  const baseStyles = mobile 
    ? "flex flex-col space-y-4" 
    : "flex items-center space-x-8";

  return (
    <div className={baseStyles}>
      <a href="#about" className="hover:text-blue-600 transition-colors">About</a>
      <a href="#utility" className="hover:text-blue-600 transition-colors">Utility</a>
      <a href="#tokenomics" className="hover:text-blue-600 transition-colors">Tokenomics</a>
      <a href="#roadmap" className="hover:text-blue-600 transition-colors">Roadmap</a>
      <a href="#community" className="hover:text-blue-600 transition-colors">Community</a>
    </div>
  );
}

function LanguageSelector() {
  return (
    <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
      <Globe size={20} />
      <span>EN</span>
    </button>
  );
}