import React from 'react';
import { MessageCircle, Twitter, Users } from 'lucide-react';
import Button from '../ui/Button';

export default function Community() {
  return (
    <section id="community" className="py-20 bg-white">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Join the Inspector Gadget Squad
          </h2>
          <p className="text-lg text-gray-600">
            Be part of a movement making crypto safer for everyone. Share your findings,
            learn from others, and vote on upcoming features.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <CommunityCard
            icon={<MessageCircle />}
            title="Active Discussion"
            description="Join our Discord for real-time discussions and updates"
          />
          <CommunityCard
            icon={<Twitter />}
            title="Latest Updates"
            description="Follow us on Twitter for the newest announcements"
          />
          <CommunityCard
            icon={<Users />}
            title="Community Forum"
            description="Share your insights and learn from other detectives"
          />
        </div>

        <div className="text-center">
          <Button onClick={() => window.open('https://discord.gg/inspectorgadget', '_blank')}>
            Join Our Community
          </Button>
        </div>
      </div>
    </section>
  );
}

function CommunityCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-gray-50 rounded-lg p-6 text-center">
      <div className="inline-block p-3 bg-blue-100 rounded-full mb-4">
        {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6 text-blue-600' })}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}