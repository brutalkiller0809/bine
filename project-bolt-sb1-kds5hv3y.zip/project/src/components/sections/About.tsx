import React from 'react';
import { Shield, CheckCircle, Award } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <img
              src="/src/daylightsavingstime-spring.gif"
              alt="Inspector Gadget Animation"
              className="rounded-full shadow-xl w-64 h-64 md:w-80 md:h-80 mx-auto"
            />
          </div>

          <div className="space-y-8">
            <h2 className="text-3xl md:text-4xl font-bold">About Inspector Gadget Coin</h2>
            <p className="text-lg text-gray-600">
              At Inspector Gadget Coin, we're redefining what a memecoin can be. Inspired by the beloved childhood cartoon,
              we merge nostalgia with innovation to create a token designed to empower and protect crypto enthusiasts.
            </p>
            <p className="text-lg text-gray-600">
              Our mission is straightforward yet impactful: to provide you with the tools and insights needed to navigate
              the cryptocurrency landscape safely and confidently.
            </p>

            <div className="space-y-4">
              <TrustIndicator
                icon={<Shield className="text-[#2B4BF2]" />}
                title="Trust & Transparency"
                description="Building a secure and promising financial future"
              />
              <TrustIndicator
                icon={<CheckCircle className="text-[#2B4BF2]" />}
                title="Innovation"
                description="Merging nostalgia with cutting-edge technology"
              />
              <TrustIndicator
                icon={<Award className="text-[#2B4BF2]" />}
                title="Community Driven"
                description="Your trusted ally in crypto investigation"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustIndicator({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start space-x-4">
      <div className="p-2 bg-blue-50 rounded-lg">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-lg">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}