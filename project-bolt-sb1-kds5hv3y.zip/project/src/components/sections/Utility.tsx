import React from 'react';
import { Search, Users, BookOpen, Bell } from 'lucide-react';

export default function Utility() {
  return (
    <section id="utility" className="py-20 bg-gray-50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            The Crypto Detective You Can Trust
          </h2>
          <p className="text-lg text-gray-600">
            Inspector Gadget Coin isn't just another meme; it's a powerful tool in your crypto toolkit.
            Designed for investors who want to navigate the murky waters of cryptocurrency safely.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <FeatureCard
            icon={<Search />}
            title="Rug Check Analysis"
            description="Integrated with rugcheck for real-time token verification"
          />
          <FeatureCard
            icon={<Users />}
            title="Community Ratings"
            description="Share insights and rate tokens based on trustworthiness"
          />
          <FeatureCard
            icon={<BookOpen />}
            title="Educational Hub"
            description="Comprehensive guides on avoiding scams and finding gems"
          />
          <FeatureCard
            icon={<Bell />}
            title="Real-Time Alerts"
            description="Instant notifications for flagged unsafe tokens"
          />
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="inline-block p-3 bg-blue-100 rounded-full mb-4">
        {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6 text-blue-600' })}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}