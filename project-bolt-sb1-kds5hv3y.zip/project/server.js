const express = require('express');
const fetch = require('node-fetch');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Solana Endpoint and API Key
const SOLANA_ENDPOINT = 'https://solana-mainnet.g.alchemy.com/v2/Md5EQ1dLUfXUrEaMRo2NWGmFzp27C-pL';

// Endpoint to fetch Solana data
app.post('/getContractData', async (req, res) => {
    try {
        const { method, params } = req.body;

        const response = await fetch(SOLANA_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                jsonrpc: '2.0',
                id: 1,
                method: method,
                params: params || [],
            }),
        });

        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to fetch data from Solana' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
