import React, { useState, useCallback, useRef, ButtonHTMLAttributes } from 'react';
import { Loader2 } from 'lucide-react';
import { debounce } from '../../utils/debounce';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  isLoading?: boolean;
  children: React.ReactNode;
}

export default function Button({
  variant = 'primary',
  isLoading = false,
  disabled,
  children,
  onClick,
  className = '',
  ...props
}: ButtonProps) {
  const [ripples, setRipples] = useState<Array<{ x: number; y: number; id: number }>>([]);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const rippleCount = useRef(0);

  const handleClick = useCallback(
    debounce((event: React.MouseEvent<HTMLButtonElement>) => {
      if (onClick) onClick(event);
      
      const button = buttonRef.current;
      if (!button) return;

      const rect = button.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      rippleCount.current += 1;
      const id = rippleCount.current;

      setRipples(prev => [...prev, { x, y, id }]);
      setTimeout(() => {
        setRipples(prev => prev.filter(ripple => ripple.id !== id));
      }, 1000);
    }, 300),
    [onClick]
  );

  const baseStyles = `
    relative
    inline-flex
    items-center
    justify-center
    px-8
    py-4
    text-base
    font-bold
    font-sans
    rounded-lg
    min-h-[44px]
    min-w-[44px]
    transition-all
    duration-200
    focus:outline-none
    focus:ring-2
    focus:ring-offset-2
    disabled:opacity-50
    disabled:cursor-not-allowed
    hover:scale-[1.02]
    active:scale-[0.98]
  `;

  const variantStyles = {
    primary: `
      bg-gradient-to-r
      from-[#2563eb]
      to-[#4f46e5]
      text-white
      focus:ring-blue-500
    `,
    secondary: `
      bg-white
      text-gray-900
      border
      border-gray-200
      hover:bg-gray-50
      focus:ring-gray-500
    `
  };

  return (
    <button
      ref={buttonRef}
      onClick={handleClick}
      disabled={disabled || isLoading}
      className={`
        ${baseStyles}
        ${variantStyles[variant]}
        ${className}
      `}
      {...props}
    >
      <span className={`flex items-center gap-2 ${isLoading ? 'invisible' : 'visible'}`}>
        {children}
      </span>
      
      {isLoading && (
        <span className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-5 h-5 animate-spin" />
        </span>
      )}

      {ripples.map(ripple => (
        <span
          key={ripple.id}
          className="absolute bg-white/30 rounded-full animate-ripple"
          style={{
            left: ripple.x,
            top: ripple.y,
            transform: 'translate(-50%, -50%)',
            width: '100px',
            height: '100px',
          }}
        />
      ))}
    </button>
  );
}